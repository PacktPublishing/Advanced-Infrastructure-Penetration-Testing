Applications built with the onos-app module will end up here.
