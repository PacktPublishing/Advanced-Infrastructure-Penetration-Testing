Following People have contributed to various features (list in no particular order):

*  @roo7break (http://roo7break.co.uk/) : added reporting functionality [added to version 3 (support discontinued in later versions).]
* @Reboare : added lxc container checks
* @phackt : added various checks (adm group, SELinux Presence, fstab)
* @anantshri (http://anantshri.info) : code optimization, loaded kernel modules listing